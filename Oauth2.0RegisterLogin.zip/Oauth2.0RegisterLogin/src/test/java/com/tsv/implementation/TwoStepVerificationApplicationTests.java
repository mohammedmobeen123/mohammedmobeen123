package com.tsv.implementation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwoStepVerificationApplicationTests {

	@Test
	void contextLoads() {
	}

}
